# Created by @dillibk777 at 15/01/23
from .slack_exception_logger import SlackExceptionLogger
